chrome.storage.local.get(['record'], function(result) {
    // result.record = 'efd7dea9-375b-91b6-6e37-6136101c0808';
    console.log('Value currently is ' + result.record);
    if(result.record !== null){

        // fetch(`https://crm.apartmentsource.com/custom/service/v4_1_custom/ListingRecord.php?listID=${result.record}`).then(r => r.text()).then(result => {
        fetch(`https://crm-dev.apartmentsource.com/custom/service/v4_1_custom/ListingRecord.php?listID=${result.record}`).then(r => r.text()).then(result => {
            console.log(JSON.parse(result));
            let data = JSON.parse(result);

            if(window.location.host == 'chicago.craigslist.org'){
                document.getElementById('post').click();
            }            
            if(window.location.host == 'post.craigslist.org'){
                
                const urlParams = new URLSearchParams(window.location.search);
                const page = urlParams.get('s');
                console.log(page);
                if(page == 'subarea'){
                    document.querySelector("input[value='1']").click();
                    document.querySelector("button[value='Continue']").click();
                }
        
                if(page == 'type'){
                    console.log('page is type')
                    document.querySelector("input[value='ho']").click();
                    document.querySelector("button[value='Continue']").click();
                }
        
                if(page == 'hcat'){
                    document.querySelector("input[value='1']").click();
                    document.querySelector("button[value='Continue']").click();
                }
        
                if(page == 'edit'){
                    document.querySelector("input[name='PostingTitle']").value = data.listDetails.name;
                    document.querySelector("input[name='geographic_area']").value = data.listDetails.city_c;
                    document.querySelector("input[name='postal']").value = data.listDetails.zip_c;
                    document.querySelector("textarea[name='PostingBody']").value = data.listDetails.propertyinfo_c;
                    document.querySelector("input[name='price']").value = data.listDetails.rent_c;
                    document.querySelector("input[name='surface_area']").value = data.listDetails.sqft_c;

                    // laundry 
                    let laundry = parseData(data.listDetails.laundry_c, 'laundry');                    
                    if (laundry) {
                        document.querySelector(".laundry .ui-selectmenu-button").click();                    
                        let laundryElement = document.querySelector('#ui-id-12');
                        laundryElement.addEventListener('mouseover', function() {
                            console.log('Laundry Event triggered');
                        });

                        let laundryEvent = new MouseEvent('mouseover', {
                            'view': window,
                            'bubbles': true,
                            'cancelable': true
                        });
                        laundryElement.dispatchEvent(laundryEvent);                    
                        document.querySelector('#ui-id-12').click();
                    }                    

                    // parking
                    let parking = parseData(data.listDetails.parking_c, 'parking');
                    if (parking) {
                        document.querySelector(".parking .ui-selectmenu-button").click();                    
                        let parkingElement = document.querySelector(parking);
                        parkingElement.addEventListener('mouseover', function() {
                            console.log('Parking Event triggered');
                        });

                        let parkingEvent = new MouseEvent('mouseover', {
                            'view': window,
                            'bubbles': true,
                            'cancelable': true
                        });
                        parkingElement.dispatchEvent(parkingEvent);                    
                        document.querySelector(parking).click();
                    }                    

                    // beds 
                    let beds = parseData(data.listDetails.beds_c, 'beds_c');
                    // console.log(beds,'line 55');
                    if (beds) {
                        document.querySelector(".bedrooms .ui-selectmenu-button").click();
                        let element = document.querySelector(beds);
                        element.addEventListener('mouseover', function() {
                            console.log('Bedroom Event triggered');
                        });

                        let event = new MouseEvent('mouseover', {
                            'view': window,
                            'bubbles': true,
                            'cancelable': true
                        });

                        element.dispatchEvent(event);
                        document.querySelector(beds).click();
                    }
                    // bathrooms
                    let bathrooms = parseData(data.listDetails.baths_c, 'baths_c');
                    if (bathrooms) {
                        document.querySelector(".bathrooms .ui-selectmenu-button").click();                    
                        let bathroomElement = document.querySelector(bathrooms);
                        bathroomElement.addEventListener('mouseover', function() {
                            console.log('Parking Event triggered');
                        });

                        let bathroomEvent = new MouseEvent('mouseover', {
                            'view': window,
                            'bubbles': true,
                            'cancelable': true
                        });
                        bathroomElement.dispatchEvent(bathroomEvent);                    
                        document.querySelector(bathrooms).click();
                    }                    

                    // Cats
                    if (
                        data.listDetails.catpolicy_c.toLowerCase() == "catsallowed" || 
                        data.listDetails.catpolicy_c.toLowerCase() == 'negotiable'
                        ) 
                    {
                        $("input[name='pets_cat']").click();   
                    } 
                    // Dogs
                    if (
                        data.listDetails.dogpolicy_c.toLowerCase() == 'dogsallowed' || 
                        data.listDetails.dogpolicy_c.toLowerCase() == 'smalldogsonly' ||
                        data.listDetails.dogpolicy_c.toLowerCase() == 'negotiable'
                        ) 
                    {
                        $("input[name='pets_dog']").click();   
                    }


                    // Available On
                    if (data.listDetails.availdate_c) {
                        formattedDate = formatDate(data.listDetails.availdate_c);
                        console.log("line 139",formattedDate);
                        $("input[data-date-input-name='movein_date']").val(formattedDate);
                    }                    
                    if (data.listDetails.application_fee_c && data.listDetails.application_fee_c != '') {
                        $("input[name='application_fee']").click();   
                        $("input[name='application_fee_explained']").val(data.listDetails.application_fee_c);
                    }       

                    // Email
                    $("input[name='FromEMail']").val(data.listDetails.useremail_c);
                    

                    // Phone Number
                    // $("input[name='show_phone_ok']").click();   
                    // $("input[name='contact_phone']").val('4703105856');

                            
                    $("button[value='continue']").click();                       

                    /*chrome.storage.local.set({record: null}, function() {
                        console.log('Value is set to empty');
                    });*/
                }

                if (page == 'geoverify') {
                    document.querySelector("input[name='xstreet0']").value = data.listDetails.name;
                    document.querySelector("input[name='xstreet1']").value = data.listDetails.city_c;
                    document.querySelector("input[name='city']").value = data.listDetails.zip_c;
                    document.querySelector('#leafletForm > button.continue').click();
                }

                if (page == 'editimage') {
                    // Image upload 
                    chrome.storage.local.set({record: null}, function() {
                        console.log('Value is set to empty');
                    });
                }
                if (page == 'preview') {
                    chrome.storage.local.set({record: null}, function() {
                        console.log('Value is set to empty');
                    });
            
                    // $("form#publish_bottom > button").click();
                }
            }
        });
    }
});

function parseData(data, field) {
    let result;
    if (field == 'beds_c') {
        switch (data) {
            case 'Convertible':
            case 'studio':
            case '1':
                result = '#ui-id-27';
                break;
            case '1.5':
            case '2':
                result = '#ui-id-28';
                break;
            case '2.5':
            case '3':
                result = '#ui-id-29';
                break;
            case '3.5':
            case '4':
                result = '#ui-id-30';
                break;
            case '4.5':
            case '5':
                result = '#ui-id-31';
                break;
            case '6':
                result = '#ui-id-32';
                break;
            case '7':
                result = '#ui-id-33';
                break;
            case '8':
                result = '#ui-id-34';
                break;
            default:
                result = '#ui-id-25';
                break;
        }
    }else if (field == 'laundry') {
        switch (data) {
            case 'w/d in unit':
            case 'Washer_Dryer_in_Unit':
                result = '#ui-id-12';
                break;
            case 'Laundry in Building':
                result = '#ui-id-14';
                break;
            case 'Laundry on Site':
            case 'Laundry Services':
                result = '#ui-id-15';
                break;
            case 'Washer/Dryer Hookups':
                result = '#ui-id-13';
                break;
            default:
                result = '#ui-id-11';
                break;
        }
    }else if (field == 'parking') {
        switch (data) {
            case 'available':
                result = '#ui-id-23';
                break;
            case 'included':
                result = '#ui-id-21';
                break;
            case 'garage':
                result = '#ui-id-19';
                break;
            case 'street':
                result = '#ui-id-22';
                break;
            default:
                result = '#ui-id-17';
                break;
        }
    }else if (field == 'baths_c') {
        if (parseInt(data) > 9) {
            data = 10;
        }
        switch (data) {
            case '1':
            case 'shared':
            case 'split':
                result = '#ui-id-38';
                break;
            case '2':
                result = '#ui-id-40';
                break;
            case '3':
                result = '#ui-id-42';
                break;
            case '4':
                result = '#ui-id-43';
                break;
            case '5':
                result = '#ui-id-45';
                break;
            case '6':
                result = '#ui-id-46';
                break;
            case '7':
                result = '#ui-id-48';
                break;
            case '8':
                result = '#ui-id-50';
                break;
            case '9':
                result = '#ui-id-52';
                break;
            case '10':
                result = '#ui-id-54';
                break;
            default:
                result = '#ui-id-35';
                break;
        }
    }
    return result;
}
function formatDate(date){
    let formattedDate = '';
    let day = '';
    if (date) {
        let months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        let days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

        let dt = new Date(date);
        let Year = dt.getFullYear();
        let mMonth = dt.getMonth();
        let nDate = dt.getDate();
        let nDay = dt.getDay();

        formattedDate = days[nDay]+', '+nDate+' '+months[mMonth]+' '+Year;
        // console.log('FormattedDate:',formattedDate);
        return formattedDate;

    }
}



const urlParams = new URLSearchParams(window.location.search);
const page = urlParams.get('module');
// const action = urlParams.get('action');
const record = urlParams.get('record');

if(page === 'crm_posting') { 
    chrome.storage.local.set({record: record}, function() {
        console.log('Value is set to ' + record);
    });
} else {
    chrome.storage.local.set({record: null}, function() {
        console.log('Value is set to empty');
    });
}




/*const urlParams = new URLSearchParams(window.location.search);
const page = urlParams.get('module');
const action = urlParams.get('action');
const record = urlParams.get('record');

console.log(`Page: ${page}`);
console.log(`Action: ${action}`);
console.log(`Record: ${record}`);
 
if(page === 'crm_Listings' && action === 'DetailView') { 
    chrome.storage.local.set({record: record}, function() {
        console.log('Value is set to ' + record);
    });
} else {
    chrome.storage.local.set({record: null}, function() {
        console.log('Value is set to empty');
    });
}*/
